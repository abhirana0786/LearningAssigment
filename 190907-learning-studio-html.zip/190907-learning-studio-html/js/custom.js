/* Equal Column Height */
$(document).ready(function() {
  //console.log("ready");
  function equalColumns(htmlElements) {
    $(htmlElements).removeAttr("style");
    var heights = $(htmlElements)
        .map(function() {
          return $(this).height();
        })
        .get(),
      maxHeight = Math.max.apply(null, heights);
    $(htmlElements).height(maxHeight);
  }
  $(window).bind("load", function() {
    window.addEventListener(
      "resize",
      function() {
        // Get screen size (inner/outerWidth, inner/outerHeight)
        setTimeout(function() {
          equalColumns(".date-col");
          equalColumns(".learnings-profile");
          equalColumns(".overdue-col");
          equalColumns(".description-col");
        }, 500);
      },
      false
    );
    setTimeout(function() {
      equalColumns(".date-col");
      equalColumns(".learnings-profile");
      equalColumns(".overdue-col");
      equalColumns(".description-col");
    }, 500);
    /* Carat/New window icon Next Line  */
  });

  $(".header-col").click(function() {
    $header = $(this);
    //getting the next element
    $content = $header.closest(".learnings-head").next();
    //open up the content needed - toggle the slide- if visible, slide up, if not slidedown.
    $content.slideToggle(500, function() {
      //execute this after slideToggle is done
      //change text of header based on visibility of content div
    });
  });

  /*Add New Learning JS*/
  $("#saveData").click(function() {
    var learnname = $("#learn-name").val();
    var username = $("#user-name").val();
    var duedate = $("#due-date").val();
    var desc = $("#description").val();
    var newrow =
      '<div class="learning-content-row"> <div class="row"> <div class="col-lg-2"> <div class="date-col"> <h4>Monday</h4> <h3>' +
      duedate +
      '</h3> </div></div><div class="col-lg-5"> <div class="learnings-profile"> <figure><img src="images/learning-2.png"/></figure> <div class="learnings-profile-right"> <h4><a href="#">' +
      learnname +
      '</a></h4> <div class="usersname">' +
      username +
      '</div></div></div></div><div class="col-lg-2"> <div class="overdue-col"> <div class="label">Overdue by:</div><div class="overdue-day">4 days</div></div></div><div class="col-lg-3"> <div class="description-col"> <i class="fa fa-file-text-o"></i> <div class="description-right-col"> <label>Description</label> <p>' +
      desc +
      "</p></div></div></div></div></div>";
    $(".learning-content-wrapper").append(newrow);
    $(".close").trigger("click");
    $("#learn-name").val("");
    $("#user-name").val("");
    $("#due-date").val("");
    $("#description").val("");
  });

  $("#my-learning").change(function() {
    if ($("#my-learning:checked")) {
      $(".learning-content-row").hide();
      $(".usersname").each(function() {
        if ($(this).text() == "admin") {
          $(this)
            .closest(".learning-content-row")
            .show();
        }
      });
    }
  });
  $("#all-learning").change(function() {
    if ($("#all-learning:checked")) {
      $(".learning-content-row").show();
    }
  });

  /*Search JS*/
  $(".search-add-learning input").on("keyup", function() {
    var value = $(this)
      .val()
      .toLowerCase();
    $(".learnings-profile-right").filter(function() {
      $(this)
        .closest(".learning-content-row")
        .toggle(
          $(this)
            .text()
            .toLowerCase()
            .indexOf(value) > -1
        );
    });
  });
});
